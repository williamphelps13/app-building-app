import { Component } from "react";
import type { ErrorInfo, ReactNode } from "react";
import { FilledButton, Group, Row } from "./ios";

/* A render error would otherwise paint a white screen, which is the
   worst thing a prototype can do in front of someone. This keeps the
   app on screen, says what broke, and offers the two recoveries that
   actually work. */
export class Guard extends Component<{ children: ReactNode }, { error: Error | null }> {
  state: { error: Error | null } = { error: null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("[aba] render failed", error, info.componentStack);
  }

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;

    return (
      <div className="min-h-screen bg-grouped px-4 pt-12 text-label antialiased">
        <div className="mx-auto max-w-2xl">
          <h1 className="mb-2 text-large-title font-bold">Something broke</h1>
          <p className="mb-8 text-subheadline leading-relaxed text-label-2">
            Your work is saved. Reloading usually fixes it, and nothing is lost if it does not.
          </p>

          <Group header="What happened">
            <Row label={error.message || String(error)} />
          </Group>

          <div className="flex flex-col gap-2">
            <FilledButton onClick={() => window.location.reload()}>Reload</FilledButton>
            <FilledButton tone="neutral" onClick={() => this.setState({ error: null })}>
              Try again without reloading
            </FilledButton>
          </div>
        </div>
      </div>
    );
  }
}
