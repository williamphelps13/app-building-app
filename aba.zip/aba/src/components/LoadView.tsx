import { useMemo, useRef, useState } from "react";
import { CADENCE, CADENCE_KEYS, WEIGHTS, WEIGHT_KEYS } from "../schema";
import type { CadenceKey, Feature, WeightKey } from "../schema";
import { MAX, TIMELINE, archiveMb, buildCurve, clamp, fmtPoint, fmtSize, snap } from "../lib";
import { Group, MenuRow, Row } from "./ios";

const LABEL = "var(--color-label)";
const SEP = "var(--color-separator)";
const LABEL3 = "var(--color-label-3)";

const W = 360, H = 150, PAD_B = 18, PAD_T = 8;

export function LoadView({
  items, mutate,
}: {
  items: Feature[];
  mutate: (id: string, fn: (item: Feature) => Feature) => void;
}) {
  const curve = useMemo(() => buildCurve(items), [items]);
  const peak = useMemo(
    () => curve.reduce((a, b) => (b.total > a.total ? b : a), curve[0]!),
    [curve],
  );
  const totalMb = useMemo(() => items.reduce((s, it) => s + archiveMb(it), 0), [items]);
  const heaviest = useMemo(
    () => [...items].sort((a, b) => archiveMb(b) - archiveMb(a))[0],
    [items],
  );

  const [probe, setProbe] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);

  const yMax = Math.max(2, Math.ceil(peak.total));
  const x = (v: number) => (v / MAX) * W;
  const y = (v: number) => H - PAD_B - (v / yMax) * (H - PAD_B - PAD_T);

  const area = (
    upper: (p: (typeof curve)[number]) => number,
    lower: (p: (typeof curve)[number]) => number,
  ) => {
    const up = curve.map((p) => `${x(p.at).toFixed(1)},${y(upper(p)).toFixed(1)}`).join(" L");
    const down = [...curve].reverse()
      .map((p) => `${x(p.at).toFixed(1)},${y(lower(p)).toFixed(1)}`).join(" L");
    return `M${up} L${down} Z`;
  };

  const read = (e: React.PointerEvent<SVGSVGElement>) => {
    const el = svgRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setProbe(clamp(snap(((e.clientX - r.left) / r.width) * MAX), 0, MAX));
  };

  const at = probe === null ? peak : curve.find((p) => p.at === probe) ?? peak;

  return (
    <>
      <section className="mb-8">
        <div className="rounded-group bg-elevated p-4">
          <div className="flex items-baseline gap-2">
            <span className="text-large-title tabular-nums text-label">{at.total.toFixed(1)}</span>
            <span className="text-footnote text-label-2">
              entries a week at {fmtPoint(at.at)}{probe === null ? " · the peak" : ""}
            </span>
          </div>

          <svg
            ref={svgRef}
            className="mt-3 block w-full touch-pan-y"
            viewBox={`0 0 ${W} ${H}`}
            role="img"
            aria-label={`Load across the timeline, peaking at ${peak.total.toFixed(1)} around ${fmtPoint(peak.at)}`}
            onPointerDown={read}
            onPointerMove={(e) => { if (e.buttons) read(e); }}
          >
            {TIMELINE.ticks.map((t) => (
              <line key={t} x1={x(t)} x2={x(t)} y1={PAD_T} y2={H - PAD_B} stroke={SEP} strokeWidth="1" />
            ))}
            <line x1="0" x2={W} y1={H - PAD_B} y2={H - PAD_B} stroke={SEP} strokeWidth="1" />

            <path d={area((p) => p.a, () => 0)} fill="var(--color-tint)" opacity="0.9" />
            <path d={area((p) => p.total, (p) => p.a)} fill="var(--color-accent)" opacity="0.9" />

            <line x1={x(at.at)} x2={x(at.at)} y1={PAD_T} y2={H - PAD_B}
              stroke={LABEL} strokeWidth="1" opacity="0.5" />
            <circle cx={x(at.at)} cy={y(at.total)} r="4" fill={LABEL} />

            {TIMELINE.ticks.map((t) => (
              <text key={t} x={x(t)} y={H - 4} fill={LABEL3} fontSize="10"
                textAnchor={t === 0 ? "start" : t === MAX ? "end" : "middle"}>{t}</text>
            ))}
            <text x="2" y={PAD_T + 8} fill={LABEL3} fontSize="10">{yMax}/wk</text>
          </svg>

          <p className="mt-2 text-footnote text-label-3">
            {probe === null
              ? "Drag to read any point."
              : `Before handover ${at.a.toFixed(1)} · after ${at.b.toFixed(1)}`}
          </p>
        </div>
      </section>

      <Group header="Data" footer="Text 10 KB · photo 4 MB · audio 1 MB · video 60 MB.">
        <Row label="Total by the end"
          secondary={heaviest ? `Mostly ${heaviest.name.toLowerCase()}` : undefined}
          trailing={<span className="tabular-nums">{fmtSize(totalMb)}</span>} />
      </Group>

      {items.map((it) => (
        <Group key={it.id} header={it.name}>
          <MenuRow<CadenceKey>
            label="How often"
            value={it.cadence}
            options={CADENCE_KEYS.map((k) => ({ value: k, label: CADENCE[k].label }))}
            onChange={(v) => mutate(it.id, (f) => ({ ...f, cadence: v }))}
          />
          <MenuRow<WeightKey>
            label="Entry size"
            value={it.weight}
            options={WEIGHT_KEYS.map((k) => ({ value: k, label: WEIGHTS[k].label }))}
            onChange={(v) => mutate(it.id, (f) => ({ ...f, weight: v }))}
          />
          <Row label="Adds up to" trailing={<span className="tabular-nums">{fmtSize(archiveMb(it))}</span>} />
        </Group>
      ))}
    </>
  );
}
