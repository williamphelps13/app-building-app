import type { ReactNode } from "react";
import { useEffect, useRef, useState } from "react";

export const cx = (...parts: (string | false | null | undefined)[]) =>
  parts.filter(Boolean).join(" ");

/* ============================================================
   Press feedback

   UIKit delays the highlight briefly and drops it the moment a
   scroll begins, which is why a plain :active feels wrong on a
   list. This reproduces that: a short delay before the press
   registers, cancelled by any real movement, and an instant
   highlight that fades out on release.
   ============================================================ */

const PRESS_DELAY = 60;
const PRESS_SLOP = 8;

export function usePress() {
  const [pressed, setPressed] = useState(false);
  const origin = useRef<{ x: number; y: number } | null>(null);
  const timer = useRef<number | null>(null);

  const cancel = () => {
    if (timer.current !== null) {
      window.clearTimeout(timer.current);
      timer.current = null;
    }
    origin.current = null;
    setPressed(false);
  };

  useEffect(() => cancel, []);

  return {
    pressed,
    bind: {
      onPointerDown: (e: React.PointerEvent) => {
        origin.current = { x: e.clientX, y: e.clientY };
        timer.current = window.setTimeout(() => setPressed(true), PRESS_DELAY);
      },
      onPointerMove: (e: React.PointerEvent) => {
        if (!origin.current) return;
        const dx = e.clientX - origin.current.x;
        const dy = e.clientY - origin.current.y;
        if (Math.hypot(dx, dy) > PRESS_SLOP) cancel();
      },
      onPointerUp: cancel,
      onPointerCancel: cancel,
      onPointerLeave: cancel,
    },
  };
}

/* Instant on the way in, a soft fade on the way out. */
export const pressFill = (pressed: boolean) =>
  cx("transition-colors", pressed ? "bg-elevated-2 duration-0" : "duration-300");

export const pressDim = (pressed: boolean) =>
  cx("transition-opacity", pressed ? "opacity-30 duration-0" : "duration-300");

/* ============================================================
   Modal chrome

   Locks the page behind a presentation and hands focus back
   where it came from on dismissal.
   ============================================================ */

export function useModalChrome(open: boolean) {
  const container = useRef<HTMLDivElement | null>(null);
  const restoreTo = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    restoreTo.current = document.activeElement as HTMLElement | null;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    container.current?.focus({ preventScroll: true });
    return () => {
      document.body.style.overflow = previous;
      restoreTo.current?.focus({ preventScroll: true });
    };
  }, [open]);

  return container;
}

/* ============================================================
   Glyphs

   Stand-ins for the SF Symbols these controls would use.
   ============================================================ */

export function ChevronRight({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 8 13" aria-hidden className={cx("h-3 w-2 shrink-0", className)}>
      <path d="M1.5 1.5 6.5 6.5 1.5 11.5" fill="none" stroke="currentColor"
        strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function ChevronUpDown({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 12 16" aria-hidden className={cx("h-4 w-3 shrink-0", className)}>
      <path d="M3 6.5 6 3.5 9 6.5M3 9.5 6 12.5 9 9.5" fill="none" stroke="currentColor"
        strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* A row that explains itself takes an info button. A row that
   leads somewhere takes a chevron. See lists and tables in the
   Human Interface Guidelines. */
export function InfoButton({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 22 22" aria-hidden className={cx("h-info w-info shrink-0", className)}>
      <circle cx="11" cy="11" r="9.2" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="11" cy="6.6" r="1.05" fill="currentColor" />
      <path d="M11 9.6v6.2" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  );
}

export function Checkmark({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 14 12" aria-hidden className={cx("h-3.5 w-3.5 shrink-0", className)}>
      <path d="M1 6.5 5 10.5 13 1.5" fill="none" stroke="currentColor"
        strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ============================================================
   Inset grouped list
   ============================================================ */

export function Group({
  header, footer, children,
}: { header?: string; footer?: string; children: ReactNode }) {
  return (
    <section className="mb-8">
      {header && (
        <h2 className="mb-2 px-4 text-footnote text-label-2">{header}</h2>
      )}
      <div className="ios-list overflow-hidden rounded-group bg-elevated">{children}</div>
      {footer && (
        <p className="mt-2 px-4 text-footnote leading-snug text-label-3">{footer}</p>
      )}
    </section>
  );
}

/* A single list row. `trailing` sits at the right edge; pass
   `onClick` to make the whole row tappable, which adds the
   disclosure chevron unless you turn it off. */
export function Row({
  label, secondary, trailing, chevron, accessory = "chevron", onClick, ariaExpanded, children,
}: {
  label?: ReactNode;
  secondary?: ReactNode;
  trailing?: ReactNode;
  chevron?: boolean;
  accessory?: "chevron" | "info" | "none";
  onClick?: () => void;
  ariaExpanded?: boolean;
  children?: ReactNode;
}) {
  const body = (
    <div className="ios-hairline flex min-h-hit items-center gap-3 border-b border-separator py-2 pr-4">
      {(label || secondary) && (
        <span className="min-w-0 flex-1 text-left">
          {label && <span className="block text-body text-label">{label}</span>}
          {secondary && <span className="mt-0.5 block text-footnote text-label-3">{secondary}</span>}
        </span>
      )}
      {children}
      {trailing && <span className="shrink-0 text-body text-label-2">{trailing}</span>}
      {chevron !== false && onClick && accessory === "chevron" && (
        <ChevronRight className="text-label-4" />
      )}
      {chevron !== false && onClick && accessory === "info" && (
        <InfoButton className="text-tint" />
      )}
    </div>
  );

  if (!onClick) return <div className="pl-4">{body}</div>;

  return <PressRow onClick={onClick} ariaExpanded={ariaExpanded}>{body}</PressRow>;
}

/* A list row that highlights the way UIKit does. */
export function PressRow({
  onClick, ariaExpanded, className, children,
}: {
  onClick: () => void;
  ariaExpanded?: boolean;
  className?: string;
  children: ReactNode;
}) {
  const { pressed, bind } = usePress();
  return (
    <button
      type="button"
      onClick={onClick}
      aria-expanded={ariaExpanded}
      {...bind}
      className={cx("block w-full pl-4 text-left select-none", pressFill(pressed), className)}
    >
      {children}
    </button>
  );
}

/* A list row you delete by swiping, as in Mail or Reminders.
   Vertical movement is handed back to the page, so a scroll that
   starts on a row never opens the action. */
export function SwipeRow({
  label, onDelete, deleteLabel = "Delete",
}: { label: ReactNode; onDelete: () => void; deleteLabel?: string }) {
  const WIDTH = 88;
  const [offset, setOffset] = useState(0);
  const start = useRef<{ x: number; y: number; from: number } | null>(null);
  const axis = useRef<"undecided" | "x" | "y">("undecided");

  const down = (e: React.PointerEvent) => {
    start.current = { x: e.clientX, y: e.clientY, from: offset };
    axis.current = "undecided";
  };

  const move = (e: React.PointerEvent) => {
    if (!start.current) return;
    const dx = e.clientX - start.current.x;
    const dy = e.clientY - start.current.y;

    if (axis.current === "undecided") {
      if (Math.abs(dy) > 10 && Math.abs(dy) > Math.abs(dx)) { axis.current = "y"; return; }
      if (Math.abs(dx) < 6) return;
      axis.current = "x";
    }
    if (axis.current !== "x") return;
    setOffset(Math.max(-WIDTH, Math.min(0, start.current.from + dx)));
  };

  const up = () => {
    if (axis.current === "x") setOffset(offset < -WIDTH / 2 ? -WIDTH : 0);
    start.current = null;
    axis.current = "undecided";
  };

  return (
    <div className="relative overflow-hidden">
      <button
        type="button"
        onClick={() => { setOffset(0); onDelete(); }}
        aria-label={`${deleteLabel} ${typeof label === "string" ? label : ""}`}
        className="absolute inset-y-0 right-0 flex w-22 items-center justify-center bg-negative
          text-body font-medium text-grouped"
        style={{ opacity: offset < -8 ? 1 : 0 }}
        tabIndex={offset < -8 ? 0 : -1}
      >
        {deleteLabel}
      </button>

      <div
        className="relative bg-elevated pl-4 touch-pan-y"
        style={{ transform: `translateX(${offset}px)`, transition: start.current ? "none" : "transform .25s cubic-bezier(.32,.72,0,1)" }}
        onPointerDown={down}
        onPointerMove={move}
        onPointerUp={up}
        onPointerCancel={up}
      >
        <div className="ios-hairline flex min-h-hit items-center border-b border-separator py-2 pr-4">
          <span className="min-w-0 flex-1 truncate text-body text-label">{label}</span>
        </div>
      </div>
    </div>
  );
}

/* A row whose trailing element is a native menu. The select is
   invisible and stretched over the row, so the platform picker
   opens on tap while the row keeps iOS presentation. */
export function MenuRow<T extends string>({
  label, value, options, onChange,
}: {
  label: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (value: T) => void;
}) {
  const current = options.find((o) => o.value === value);
  return (
    <div className="relative pl-4">
      <div className="ios-hairline flex min-h-hit items-center gap-3 border-b border-separator py-2 pr-4">
        <span className="min-w-0 flex-1 text-body text-label">{label}</span>
        <span className="shrink-0 text-body text-label-2">{current?.label ?? value}</span>
        <ChevronUpDown className="text-label-4" />
      </div>
      <select
        aria-label={label}
        value={value}
        onChange={(e) => onChange(e.target.value as T)}
        /* text-callout keeps iOS from zooming when the menu opens. */
        className="absolute inset-0 h-full w-full cursor-pointer text-callout opacity-0"
      >
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

/* One-of-N selection, the iOS way: a checkmark on the chosen row. */
export function CheckRow({
  label, secondary, selected, onSelect,
}: {
  label: string;
  secondary?: string;
  selected: boolean;
  onSelect: () => void;
}) {
  const { pressed, bind } = usePress();
  return (
    <button
      type="button"
      onClick={onSelect}
      role="option"
      aria-selected={selected}
      {...bind}
      className={cx("block w-full select-none pl-4 text-left", pressFill(pressed))}
    >
      <div className="ios-hairline flex min-h-hit items-center gap-3 border-b border-separator py-2 pr-4">
        <span className="min-w-0 flex-1">
          <span className="block text-body text-label">{label}</span>
          {secondary && <span className="mt-0.5 block text-footnote text-label-3">{secondary}</span>}
        </span>
        {selected && <Checkmark className="text-tint" />}
      </div>
    </button>
  );
}

/* ============================================================
   Controls
   ============================================================ */

export function SegmentedControl<T extends string>({
  value, options, onChange, size = "regular",
}: {
  value: T;
  options: { value: T; label: string }[];
  onChange: (value: T) => void;
  size?: "regular" | "small";
}) {
  return (
    <div
      role="tablist"
      className={cx(
        "flex gap-0.5 rounded-control bg-fill p-0.5",
        size === "regular" ? "h-8" : "h-7",
      )}
    >
      {options.map((o) => {
        const on = o.value === value;
        return (
          <button
            key={o.value}
            type="button"
            role="tab"
            aria-selected={on}
            onClick={() => onChange(o.value)}
            className={cx(
              "flex flex-1 items-center justify-center rounded-segment px-3 transition-colors",
              size === "regular" ? "text-subheadline" : "text-footnote",
              on
                ? "bg-elevated-2 font-semibold text-label shadow-sm ring-1 ring-black/20"
                : "text-label-2",
            )}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

/* UIStepper: one capsule, minus and plus either side of a divider. */
export function Stepper({
  label, onDecrement, onIncrement,
}: { label: string; onDecrement: () => void; onIncrement: () => void }) {
  const half = "flex h-8 w-11 select-none items-center justify-center text-title3 leading-none text-label active:bg-elevated-2";
  return (
    <span className="flex shrink-0 overflow-hidden rounded-control bg-fill">
      <button type="button" className={half} aria-label={`${label} down`} onClick={onDecrement}>−</button>
      <span className="w-px bg-separator" aria-hidden />
      <button type="button" className={half} aria-label={`${label} up`} onClick={onIncrement}>+</button>
    </span>
  );
}

export function FilledButton({
  children, onClick, tone = "tint", disabled = false,
}: {
  children: ReactNode;
  onClick: () => void;
  tone?: "tint" | "neutral";
  disabled?: boolean;
}) {
  const { pressed, bind } = usePress();
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      {...bind}
      className={cx(
        "flex h-hit w-full select-none items-center justify-center rounded-button text-body font-semibold transition-opacity",
        pressed && !disabled ? "opacity-60 duration-0" : "duration-300",
        disabled && "opacity-40",
        tone === "tint" ? "bg-tint text-grouped" : "bg-fill text-label",
      )}
    >
      {children}
    </button>
  );
}

export function PlainButton({
  children, onClick, tone = "tint",
}: { children: ReactNode; onClick: () => void; tone?: "tint" | "destructive" }) {
  const { pressed, bind } = usePress();
  return (
    <button
      type="button"
      onClick={onClick}
      {...bind}
      className={cx(
        "select-none text-body",
        pressDim(pressed),
        tone === "tint" ? "text-tint" : "text-negative",
      )}
    >
      {children}
    </button>
  );
}

/* ============================================================
   Sheet

   Modal presentation: dimmed backdrop, rounded top corners,
   grabber, and a Done button in the sheet's own nav bar.
   ============================================================ */

export function Sheet({
  title, open, onClose, children,
}: { title: string; open: boolean; onClose: () => void; children: ReactNode }) {
  const [dragY, setDragY] = useState(0);
  const from = useRef<number | null>(null);
  const container = useModalChrome(open);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  useEffect(() => { if (!open) setDragY(0); }, [open]);

  if (!open) return null;

  /* The grabber implies the sheet can be pulled down, so it can. */
  const startDrag = (e: React.PointerEvent) => {
    from.current = e.clientY;
    (e.target as Element).setPointerCapture?.(e.pointerId);
  };
  const moveDrag = (e: React.PointerEvent) => {
    if (from.current === null) return;
    setDragY(Math.max(0, e.clientY - from.current));
  };
  const endDrag = () => {
    if (from.current === null) return;
    from.current = null;
    if (dragY > 96) onClose(); else setDragY(0);
  };

  return (
    <div ref={container} tabIndex={-1} role="dialog" aria-modal aria-label={title}
      className="fixed inset-0 z-50 flex flex-col justify-end focus:outline-none">
      <button type="button" aria-label="Close" onClick={onClose}
        className="anim-fade absolute inset-0 bg-black/50" />
      <div
        className={cx("relative max-h-[92vh] overflow-hidden rounded-t-sheet bg-elevated",
          dragY === 0 && "anim-sheet")}
        style={dragY ? { transform: `translateY(${dragY}px)` } : undefined}
      >
        <div
          className="cursor-grab touch-none active:cursor-grabbing"
          onPointerDown={startDrag}
          onPointerMove={moveDrag}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
        >
          <div className="flex justify-center pt-1.5 pb-1">
            <span className="h-1 w-9 rounded-full bg-label-4" aria-hidden />
          </div>
          <div className="flex items-center border-b border-separator px-4 pb-2.5">
            <span className="flex-1 text-headline font-semibold text-label">{title}</span>
            <PlainButton onClick={onClose}>Done</PlainButton>
          </div>
        </div>
        <div className="max-h-[76vh] overflow-y-auto overscroll-contain px-4 py-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
          {children}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   Action sheet and alert

   Destructive actions get a confirmation, and secondary
   commands live in a menu rather than crowding the nav bar.
   ============================================================ */

export interface Action {
  label: string;
  onSelect: () => void;
  destructive?: boolean;
}

export function ActionSheet({
  open, onClose, actions, message,
}: { open: boolean; onClose: () => void; actions: Action[]; message?: string }) {
  const container = useModalChrome(open);
  if (!open) return null;
  return (
    <div ref={container} tabIndex={-1} role="dialog" aria-modal
      className="fixed inset-0 z-50 flex flex-col justify-end p-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] focus:outline-none">
      <button type="button" aria-label="Cancel" onClick={onClose}
        className="anim-fade absolute inset-0 bg-black/50" />
      <div className="anim-sheet relative">
        <div className="ios-list mb-2 overflow-hidden rounded-sheet bg-elevated">
          {message && (
            <p className="border-b border-separator px-4 py-3 text-center text-footnote text-label-3">
              {message}
            </p>
          )}
          {actions.map((a) => (
            <button
              key={a.label}
              type="button"
              onClick={() => { a.onSelect(); onClose(); }}
              className={cx(
                "ios-hairline flex min-h-sheet-row w-full select-none items-center justify-center border-b border-separator px-4 text-body active:bg-elevated-2",
                a.destructive ? "text-negative" : "text-tint",
              )}
            >
              {a.label}
            </button>
          ))}
        </div>
        <button
          type="button"
          onClick={onClose}
          className="flex min-h-sheet-row w-full items-center justify-center rounded-sheet bg-elevated text-body font-semibold text-tint active:bg-elevated-2"
        >
          Cancel
        </button>
      </div>
    </div>
  );
}

export function Alert({
  open, title, message, confirmLabel, destructive, onConfirm, onCancel,
}: {
  open: boolean;
  title: string;
  message?: string;
  confirmLabel: string;
  destructive?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const container = useModalChrome(open);
  if (!open) return null;
  return (
    <div ref={container} tabIndex={-1} role="alertdialog" aria-modal aria-label={title}
      className="fixed inset-0 z-50 flex items-center justify-center p-8 focus:outline-none">
      <button type="button" aria-label="Cancel" onClick={onCancel}
        className="anim-fade absolute inset-0 bg-black/50" />
      <div className="anim-fade relative w-full max-w-70 overflow-hidden rounded-sheet bg-elevated text-center">
        <div className="px-4 pt-5 pb-4">
          <p className="text-headline font-semibold text-label">{title}</p>
          {message && <p className="mt-1 text-footnote text-label-2">{message}</p>}
        </div>
        <div className="flex border-t border-separator">
          <button type="button" onClick={onCancel}
            className="flex-1 border-r border-separator py-3 text-body text-tint active:bg-elevated-2">
            Cancel
          </button>
          <button type="button" onClick={onConfirm}
            className={cx("flex-1 py-3 text-body font-semibold active:bg-elevated-2",
              destructive ? "text-negative" : "text-tint")}>
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   Tab bar

   Top-level navigation. Fixed to the bottom edge, above the
   home indicator, with a hairline on top.
   ============================================================ */

export function TabBar<T extends string>({
  value, tabs, onChange,
}: {
  value: T;
  tabs: { value: T; label: string; icon: ReactNode }[];
  onChange: (value: T) => void;
}) {
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-separator bg-elevated pb-[env(safe-area-inset-bottom)]"
      aria-label="Sections"
    >
      <div className="mx-auto flex h-tabbar max-w-2xl">
        {tabs.map((t) => {
          const on = t.value === value;
          return (
            <button
              key={t.value}
              type="button"
              aria-current={on ? "page" : undefined}
              onClick={() => onChange(t.value)}
              className={cx(
                "flex flex-1 select-none flex-col items-center justify-center gap-0.5 transition-opacity active:opacity-60",
                on ? "text-tint" : "text-label-3",
              )}
            >
              {t.icon}
              <span className="text-caption2">{t.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

export function IconList() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className="h-6 w-6">
      <path d="M4 7h16M4 12h16M4 17h10" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

export function IconChart() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className="h-6 w-6">
      <path d="M4 4v15a1 1 0 0 0 1 1h15" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M7 15l4-5 3 3 4-6" fill="none" stroke="currentColor" strokeWidth="2"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function IconLayers() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className="h-6 w-6">
      <path d="M12 3l8 4-8 4-8-4 8-4z" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
      <path d="M4 12l8 4 8-4M4 16.5l8 4 8-4" fill="none" stroke="currentColor" strokeWidth="2"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function IconKeep() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className="h-6 w-6">
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="1.8" />
      <path d="M8 12.4 10.9 15.2 16 9.4" fill="none" stroke="currentColor" strokeWidth="2"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function IconPass() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className="h-6 w-6">
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="1.8" />
      <path d="M9 9l6 6M15 9l-6 6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

export function IconBack() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className="h-6 w-6">
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="1.8" />
      <path d="M14 8.5 10 12l4 3.5" fill="none" stroke="currentColor" strokeWidth="2"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function IconQuestion() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className="h-6 w-6">
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M9.2 9.3a2.9 2.9 0 1 1 3.6 2.8c-.5.2-.8.7-.8 1.2v.6" fill="none"
        stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <circle cx="12" cy="17" r="1.1" fill="currentColor" />
    </svg>
  );
}

export function IconEvidence() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className="h-6 w-6">
      <circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M15.5 15.5 20.5 20.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M8 10.6l1.8 1.8L13.2 9" fill="none" stroke="currentColor" strokeWidth="1.8"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function IconDecisions() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className="h-6 w-6">
      <path d="M12 3v18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M12 8h6.5l2 2.5-2 2.5H12M12 15H5.5l-2-2.5" fill="none" stroke="currentColor"
        strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function IconTools() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className="h-6 w-6">
      <path d="M14.5 6.5a3.5 3.5 0 0 0 4.6 4.6l-8 8a2.3 2.3 0 0 1-3.2-3.2l8-8a3.5 3.5 0 0 0-1.4-1.4z"
        fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );
}

export function IconGlobe() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className="h-6 w-6">
      <circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M3.5 12h17M12 3.5c2.2 2.4 3.3 5.3 3.3 8.5S14.2 18.1 12 20.5c-2.2-2.4-3.3-5.3-3.3-8.5S9.8 5.9 12 3.5z"
        fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function IconEllipsis() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className="h-7 w-7">
      <circle cx="12" cy="12" r="9.5" fill="none" stroke="currentColor" strokeWidth="1.6" />
      <circle cx="7.5" cy="12" r="1.3" fill="currentColor" />
      <circle cx="12" cy="12" r="1.3" fill="currentColor" />
      <circle cx="16.5" cy="12" r="1.3" fill="currentColor" />
    </svg>
  );
}

/* Clipboard write, reported honestly so callers can tell the user
   whether it worked. */
export async function copyPlain(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

/* Nothing to show, the iOS way: symbol, title, one line of guidance. */
export function Unavailable({
  title, message,
}: { title: string; message?: string }) {
  return (
    <div className="flex flex-col items-center px-8 py-16 text-center">
      <svg viewBox="0 0 24 24" aria-hidden className="mb-3 h-12 w-12 text-label-4">
        <circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" strokeWidth="1.8" />
        <path d="M16.5 16.5 21 21" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      </svg>
      <p className="text-headline font-semibold text-label-2">{title}</p>
      {message && <p className="mt-1 text-subheadline text-label-3">{message}</p>}
    </div>
  );
}

/* ============================================================
   Small display pieces
   ============================================================ */

export function Scale({ score, tone }: { score: number; tone: "positive" | "negative" }) {
  const on = tone === "positive" ? "bg-positive" : "bg-negative";
  return (
    <span className="flex shrink-0 gap-1" aria-hidden>
      {[1, 2, 3, 4, 5].map((n) => (
        <i key={n} className={cx("block h-1.5 w-1.5 rounded-full", n <= score ? on : "bg-separator")} />
      ))}
    </span>
  );
}
