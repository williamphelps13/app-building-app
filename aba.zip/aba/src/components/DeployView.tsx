import { useState } from "react";
import { DEPLOY } from "../data";
import { Group, Row, Sheet } from "./ios";

/* The steps live in the app because this is the thing I forget
   between deploys, and a note in a chat transcript is not somewhere
   I can look. */
export function DeployView() {
  const [detail, setDetail] = useState<{ title: string; body: string } | null>(null);

  return (
    <>
      <p className="mb-7 px-4 text-subheadline leading-relaxed text-label-2">{DEPLOY.intro}</p>

      <Group header="Steps">
        {DEPLOY.steps.map((s, i) => (
          <Row
            key={s.step}
            label={<span><span className="tabular-nums text-label-3">{i + 1}. </span>{s.step}</span>}
            accessory="info"
            onClick={() => setDetail({ title: s.step, body: s.detail })}
          />
        ))}
      </Group>

      <Group header="Worth knowing">
        {DEPLOY.notes.map((n) => (
          <Row
            key={n.note}
            label={n.note}
            accessory="info"
            onClick={() => setDetail({ title: n.note, body: n.detail })}
          />
        ))}
      </Group>

      <Sheet title="Why" open={!!detail} onClose={() => setDetail(null)}>
        {detail && (
          <>
            <p className="mb-4 text-body font-semibold leading-snug text-label">{detail.title}</p>
            <p className="text-body leading-relaxed text-label-2">{detail.body}</p>
          </>
        )}
      </Sheet>
    </>
  );
}
