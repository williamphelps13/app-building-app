import { useState } from "react";
import { CONVENTIONS } from "../data";
import { Group, Row, Sheet } from "./ios";

/* Each rule opens to its reasoning. The rule alone is the thing
   you skim; the reason is what stops a future session arguing
   with it. */
export function ConventionsView() {
  const [open, setOpen] = useState<{ rule: string; why: string } | null>(null);

  return (
    <>
      <p className="mb-7 px-4 text-subheadline leading-relaxed text-label-2">{CONVENTIONS.intro}</p>

      {CONVENTIONS.sections.map((section) => (
        <Group key={section.id} header={section.header} footer={section.summary}>
          {section.rules.map((r) => (
            <Row key={r.rule} label={r.rule} accessory="info" onClick={() => setOpen(r)} />
          ))}
        </Group>
      ))}

      <Sheet title="Why" open={!!open} onClose={() => setOpen(null)}>
        {open && (
          <>
            <p className="mb-4 text-body font-semibold leading-snug text-label">{open.rule}</p>
            <p className="text-body leading-relaxed text-label-2">{open.why}</p>
          </>
        )}
      </Sheet>
    </>
  );
}
