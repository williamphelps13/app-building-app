import { Group, Row, Unavailable } from "./ios";

/* A page that says what will live here and nothing more. Better
   than invented content, and it keeps the shape visible while
   the real records are still in a chat transcript. */

export interface PlannedSection {
  header: string;
  lines: string[];
}

export function Placeholder({
  title, summary, sections,
}: { title: string; summary: string; sections: PlannedSection[] }) {
  return (
    <>
      <p className="mb-7 px-4 text-subheadline leading-relaxed text-label-2">{summary}</p>

      {sections.map((s) => (
        <Group key={s.header} header={s.header}>
          {s.lines.map((line) => (
            <Row key={line} label={<span className="text-label-3">{line}</span>} />
          ))}
        </Group>
      ))}

      <Unavailable title={`${title} is empty`} message="Nothing has been added yet." />
    </>
  );
}
