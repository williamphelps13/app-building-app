import { TIMELINE, clamp, fmtPoint, pct } from "../lib";
import type { Feature } from "../schema";

/* A read-only picture of the range. Editing happens through the
   steppers in the feature sheet, so there is no way to change a
   range by accident while scrolling. */
export function Track({ item }: { item: Feature }) {
  const span = Math.max(item.end - item.start, 0);
  const share = span === 0
    ? 100
    : ((clamp(item.handoff, item.start, item.end) - item.start) / span) * 100;
  const notchVisible = item.handoff > item.start && item.handoff < item.end;

  return (
    <div
      className="relative h-3 rounded-full bg-fill"
      role="img"
      aria-label={`${fmtPoint(item.start)} to ${fmtPoint(item.end)}, handover at ${fmtPoint(item.handoff)}`}
    >
      {TIMELINE.ticks.slice(1, -1).map((t) => (
        <div key={t} className="absolute top-0 bottom-0 w-px bg-separator" style={{ left: `${pct(t)}%` }} />
      ))}

      <div
        className="absolute top-0 bottom-0 flex overflow-hidden rounded-full"
        style={{ left: `${pct(item.start)}%`, width: `${pct(span)}%` }}
      >
        <div className="bg-tint" style={{ width: `${share}%` }} />
        <div className="flex-1 bg-accent" />
      </div>

      {notchVisible && (
        <div
          className="absolute top-0 bottom-0 -ml-0.5 w-1 rounded-full bg-grouped"
          style={{ left: `${pct(item.handoff)}%` }}
          aria-hidden
        />
      )}
    </div>
  );
}
