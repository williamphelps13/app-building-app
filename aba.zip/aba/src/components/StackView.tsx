import { useMemo, useState } from "react";
import { CRITERIA, DEFAULT_WEIGHTS } from "../schema";
import type { StackOption, Weights } from "../schema";
import { STACK } from "../data";
import { rankLayer } from "../lib";
import { FilledButton, Group, Row, Scale, SegmentedControl, Sheet } from "./ios";

/* One entry's path through whichever options are in force. */
const FLOW: Record<string, Record<string, string>> = {
  frontend: {
    react: "You open the installed React app and add an entry.",
    tanstack: "You open the installed TanStack Start app and add an entry.",
    swiftui: "You open the iOS app and capture through the native controls.",
  },
  offline: {
    outbox: "It goes into a Dexie outbox marked pending, whether or not you have signal.",
    powersync: "It is written to the local SQLite replica, which is authoritative for reads.",
    syncthing: "The app writes the file into the watched folder and nothing else happens yet.",
  },
  runtime: {
    home: "When the device can reach the machine at home, it posts to the Node service.",
    vps: "It posts to the service on your rented box over HTTPS.",
    baas: "The client writes straight to Supabase, with row-level security deciding what is allowed.",
  },
  media: {
    immich: "Media goes to Immich, which keeps the original and handles thumbnails. The entry stores its asset id.",
    own: "The original is stored under its hash, untouched, and sharp derives a thumbnail beside it.",
    photokit: "Only the Photos identifier is stored; the file stays in the library.",
  },
  archive: {
    files: "An entry.md is written into today's dated folder with a JSON sidecar beside it.",
    sqlitefile: "A row lands in the entries table, pointing at the media by digest.",
    pg: "A row lands in Postgres with the object key recorded against it.",
  },
  index: {
    fts: "The indexer picks up the new entry and updates index.db, which stays disposable.",
    client: "Nothing happens now; the search index is rebuilt next time the app opens.",
    meili: "The entry is pushed to Meilisearch for indexing.",
  },
  access: {
    tailscale: "Your other devices, on the same tailnet, see it next time the app opens.",
    profiles: "It carries your profile as its author, and other devices show it under your name.",
    betterauth: "Permissions decide who sees it, and it appears for anyone with the right role.",
  },
  backup: {
    kopia: "That night Kopia snapshots the folder to Backblaze B2, deduplicated and encrypted.",
    restic: "That night restic snapshots the folder to Backblaze B2, deduplicated and encrypted.",
    borg: "That night Borg snapshots the folder locally, and rclone pushes the repository offsite.",
  },
};

const FLOW_ORDER = ["frontend", "offline", "runtime", "media", "archive", "index", "access", "backup"];

function OptionSheet({
  option, score, chosen, open, onClose, onChoose,
}: {
  option: StackOption | null;
  score: number;
  chosen: boolean;
  open: boolean;
  onClose: () => void;
  onChoose: () => void;
}) {
  if (!option) return null;

  return (
    <Sheet title={option.name} open={open} onClose={onClose}>
      <div className="mb-5 flex flex-wrap gap-1.5">
        {option.tech.map((t) => (
          <span key={t} className="rounded-control bg-fill px-2 py-1 font-mono text-caption text-label-2">
            {t}
          </span>
        ))}
      </div>

      <p className="mb-3 border-l-2 border-tint pl-3 text-body leading-relaxed text-label">
        {option.build}
      </p>
      <p className="mb-6 text-subheadline leading-relaxed text-label-2">{option.desc}</p>

      <Group header="In its favour">
        {option.pros.map((p) => (
          <Row key={p}>
            <span className="flex min-w-0 flex-1 gap-2.5 py-1 text-subheadline leading-relaxed text-label-2">
              <span className="text-positive">+</span>{p}
            </span>
          </Row>
        ))}
      </Group>

      <Group header="Against it">
        {option.cons.map((c) => (
          <Row key={c}>
            <span className="flex min-w-0 flex-1 gap-2.5 py-1 text-subheadline leading-relaxed text-label-2">
              <span className="text-negative">−</span>{c}
            </span>
          </Row>
        ))}
      </Group>

      <Group header="Scores" footer={`Weighted total ${score.toFixed(1)} out of 5.`}>
        {CRITERIA.map((c) => (
          <Row key={c.key} label={c.label}>
            <span className="ml-auto"><Scale score={option.scores[c.key]} tone="positive" /></span>
          </Row>
        ))}
      </Group>

      <FilledButton tone={chosen ? "neutral" : "tint"} onClick={onChoose}>
        {chosen ? "Clear this pick" : "Pick this"}
      </FilledButton>
    </Sheet>
  );
}

export function StackView({
  choices, weights, setChoices, setWeights,
}: {
  choices: Record<string, string | null>;
  weights: Weights;
  setChoices: (next: Record<string, string | null>) => void;
  setWeights: (next: Weights) => void;
}) {
  const [sheet, setSheet] = useState<{ layer: string; option: string } | null>(null);

  const ranked = useMemo(
    () => Object.fromEntries(STACK.map((l) => [l.id, rankLayer(l, weights)])),
    [weights],
  );

  const current = useMemo(
    () => Object.fromEntries(STACK.map((l) => [l.id, choices[l.id] ?? ranked[l.id]![0]!.opt.id])),
    [choices, ranked],
  );

  const openLayer = sheet ? STACK.find((l) => l.id === sheet.layer) ?? null : null;
  const openEntry = openLayer && sheet
    ? ranked[openLayer.id]!.find((r) => r.opt.id === sheet.option) ?? null
    : null;

  return (
    <>
      <Group header="As it stands">
        {STACK.map((layer) => {
          const top = ranked[layer.id]![0]!;
          const picked = layer.options.find((op) => op.id === choices[layer.id]) ?? null;
          return (
            <Row
              key={layer.id}
              label={layer.name}
              trailing={
                <span className="block max-w-45 text-right">
                  <span className="block text-body text-label-2">{(picked ?? top.opt).name}</span>
                  {!picked && (
                    <span className="block text-caption text-label-4">not picked</span>
                  )}
                </span>
              }
            />
          );
        })}
      </Group>

      <Group header="What matters" footer="Weights decide what each layer recommends.">
        {CRITERIA.map((c) => (
          <Row key={c.key} label={c.label}>
            <span className="ml-auto w-32 shrink-0">
              <SegmentedControl
                size="small"
                value={String(weights[c.key])}
                options={[0, 1, 2, 3].map((n) => ({ value: String(n), label: String(n) }))}
                onChange={(v) => setWeights({ ...weights, [c.key]: Number(v) })}
              />
            </span>
          </Row>
        ))}
        <Row label="Reset weights" onClick={() => setWeights(DEFAULT_WEIGHTS)} chevron={false} />
      </Group>

      <Group header="One entry, end to end">
        {FLOW_ORDER.map((layerId, i) => {
          const text = FLOW[layerId]?.[current[layerId] ?? ""];
          if (!text) return null;
          return (
            <Row key={layerId}>
              <span className="flex min-w-0 flex-1 gap-3 py-1.5">
                <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-fill text-caption2 tabular-nums text-label-3">
                  {i + 1}
                </span>
                <span className="text-subheadline leading-relaxed text-label-2">{text}</span>
              </span>
            </Row>
          );
        })}
      </Group>

      {STACK.map((layer) => (
        <Group key={layer.id} header={layer.name} footer={layer.question}>
          {ranked[layer.id]!.map(({ opt, score }, i) => {
            const chosen = choices[layer.id] === opt.id;
            return (
              <Row
                key={opt.id}
                label={
                  <span className="flex items-center gap-2">
                    {opt.name}
                    {i === 0 && (
                      <span className="rounded bg-fill px-1.5 py-0.5 text-caption2 uppercase tracking-wide text-positive">
                        Best
                      </span>
                    )}
                    {chosen && (
                      <span className="rounded bg-fill px-1.5 py-0.5 text-caption2 uppercase tracking-wide text-tint">
                        Picked
                      </span>
                    )}
                  </span>
                }
                secondary={opt.tech.slice(0, 3).join(" · ")}
                trailing={<span className="text-subheadline tabular-nums">{score.toFixed(1)}</span>}
                onClick={() => setSheet({ layer: layer.id, option: opt.id })}
              />
            );
          })}
        </Group>
      ))}

      <OptionSheet
        option={openEntry?.opt ?? null}
        score={openEntry?.score ?? 0}
        chosen={!!sheet && choices[sheet.layer] === sheet.option}
        open={!!sheet}
        onClose={() => setSheet(null)}
        onChoose={() => {
          if (!sheet) return;
          setChoices({
            ...choices,
            [sheet.layer]: choices[sheet.layer] === sheet.option ? null : sheet.option,
          });
          setSheet(null);
        }}
      />
    </>
  );
}
