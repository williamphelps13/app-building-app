import { useMemo } from "react";
import {
  ASPECTS, CADENCE, CADENCE_KEYS, FIELD_TYPES, NEEDS, NEED_KEYS, SORTS, WEIGHTS, WEIGHT_KEYS,
} from "../schema";
import type { AspectKey, CadenceKey, Feature, Field, NeedKey, SortKey, WeightKey } from "../schema";
import { MAX, STEP, TIMELINE, archiveMb, fmtPoint, fmtSize, pct } from "../lib";
import type { Edge } from "../lib";
import {
  CheckRow, ChevronRight, Group, MenuRow, PressRow, Row, Scale, SegmentedControl,
  Sheet, Stepper, Unavailable, cx,
} from "./ios";
import { Track } from "./Track";

export interface ControlState {
  sortA: SortKey;
  sortB: SortKey | "none";
  filterKey: AspectKey | "none";
  filterMin: number;
}

/* ============================================================
   Sort and filter, as a settings group
   ============================================================ */

export function Controls({
  ctl, set, shownCount, total,
}: {
  ctl: ControlState;
  set: (patch: Partial<ControlState>) => void;
  shownCount: number;
  total: number;
}) {
  const sortOptions = SORTS.map((s) => ({ value: s.key, label: s.label }));
  return (
    <Group
      header={ctl.filterKey === "none" ? `${total} features` : `${shownCount} of ${total} features`}
    >
      <MenuRow label="Sort by" value={ctl.sortA} options={sortOptions}
        onChange={(v) => set({ sortA: v })} />
      <MenuRow label="Then by" value={ctl.sortB}
        options={[
          { value: "none" as SortKey | "none", label: "Nothing" },
          ...sortOptions.filter((s) => s.value !== ctl.sortA),
        ]}
        onChange={(v) => set({ sortB: v })} />
      <MenuRow label="Only show" value={ctl.filterKey}
        options={[
          { value: "none" as AspectKey | "none", label: "Everything" },
          ...ASPECTS.map((a) => ({ value: a.key as AspectKey | "none", label: a.full })),
        ]}
        onChange={(v) => set({ filterKey: v })} />
      {ctl.filterKey !== "none" && (
        <MenuRow label="Rated at least" value={String(ctl.filterMin)}
          options={[5, 4, 3, 2].map((n) => ({ value: String(n), label: `${n} of 5` }))}
          onChange={(v) => set({ filterMin: Number(v) })} />
      )}
    </Group>
  );
}

/* ============================================================
   The list of features
   ============================================================ */

function Axis() {
  return (
    <div className="mb-2 px-0 pt-1 pb-1.5">
      <div className="relative h-4 text-caption2 tabular-nums text-label-3">
        {TIMELINE.ticks.map((t) => (
          <span key={t} className="absolute" style={{
            left: `${pct(t)}%`,
            transform: t === 0 ? "none" : t === MAX ? "translateX(-100%)" : "translateX(-50%)",
          }}>{t}</span>
        ))}
      </div>
    </div>
  );
}

function RatingSummary({ ratings, activeKeys }: {
  ratings: Feature["ratings"];
  activeKeys: AspectKey[];
}) {
  return (
    <span className="mt-3 grid grid-cols-2 gap-x-5 gap-y-1.5">
      {ASPECTS.map((a) => (
        <span key={a.key}
          className={cx("flex items-center gap-2 text-caption",
            activeKeys.includes(a.key) ? "text-label" : "text-label-3")}>
          <span className="w-12">{a.label}</span>
          <Scale score={ratings[a.key]} tone={a.kind === "good" ? "positive" : "negative"} />
        </span>
      ))}
    </span>
  );
}

export function FeatureList({
  shown, onOpen, activeKeys,
}: {
  shown: Feature[];
  onOpen: (id: string) => void;
  activeKeys: AspectKey[];
}) {
  if (shown.length === 0) {
    return <Unavailable title="No matches" message="Lower the bar or change the aspect." />;
  }

  return (
    <div className="mb-8">
      <Axis />
      <div className="ios-list overflow-hidden rounded-group bg-elevated">
        {shown.map((item) => (
          <div key={item.id}>
            {/* The whole row is the tap target, the iOS way. */}
            <PressRow onClick={() => onOpen(item.id)}>
              <span className="ios-hairline block border-b border-separator py-3 pr-4">
                <span className="flex items-center gap-2">
                  <span className="text-body text-label">{item.name}</span>
                  {item.note && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />}
                  <span className="ml-auto shrink-0 text-caption tabular-nums text-label-3">
                    {fmtPoint(item.start)}–{fmtPoint(item.end)}
                  </span>
                  <ChevronRight className="shrink-0 text-label-4" />
                </span>

                <span className="mt-2.5 block">
                  <Track item={item} />
                </span>

                <RatingSummary ratings={item.ratings} activeKeys={activeKeys} />
              </span>
            </PressRow>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   Feature detail, presented as a sheet
   ============================================================ */

function FieldRows({ fields, onChange }: {
  fields: Field[];
  onChange: (fields: Field[]) => void;
}) {
  const set = (i: number, patch: Partial<Field>) =>
    onChange(fields.map((f, j) => (j === i ? { ...f, ...patch } : f)));

  return (
    <>
      {fields.map((f, i) => (
        <div className="pl-4" key={i}>
          <div className="ios-hairline flex min-h-hit items-center gap-2 border-b border-separator py-2 pr-4">
            <input
              value={f.name}
              placeholder="Field name"
              aria-label="Field name"
              onChange={(e) => set(i, { name: e.target.value })}
              className="min-w-0 flex-1 bg-transparent text-body text-label placeholder:text-label-4 focus:outline-none"
            />
            <div className="relative shrink-0">
              <span className="text-body text-label-2">{f.type}</span>
              <select
                aria-label="Field type"
                value={f.type}
                onChange={(e) => set(i, { type: e.target.value as Field["type"] })}
                className="absolute inset-0 h-full w-full cursor-pointer text-callout opacity-0"
              >
                {FIELD_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <button
              type="button"
              aria-label={`Remove ${f.name || "field"}`}
              onClick={() => onChange(fields.filter((_, j) => j !== i))}
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-fill text-title3 leading-none text-negative"
            >−</button>
          </div>
        </div>
      ))}
      <Row label="Add field" onClick={() => onChange([...fields, { name: "", type: "text" }])} chevron={false} />
    </>
  );
}

export function FeatureSheet({
  item, open, onClose, onNudge, mutate,
}: {
  item: Feature | null;
  open: boolean;
  onClose: () => void;
  onNudge: (id: string, which: Edge, delta: number) => void;
  mutate: (id: string, fn: (item: Feature) => Feature) => void;
}) {
  if (!item) return null;

  const edges: { key: Edge; label: string }[] = [
    { key: "start", label: "Starts" },
    { key: "handoff", label: "Handover" },
    { key: "end", label: "Ends" },
  ];

  return (
    <Sheet title={item.name} open={open} onClose={onClose}>
      <p className="mb-6 text-subheadline leading-relaxed text-label-2">{item.blurb}</p>

      <Group header="Range">
        {edges.map((e) => (
          <Row key={e.key} label={e.label}>
            <span className="ml-auto flex items-center gap-3">
              <span className="w-16 text-right text-subheadline tabular-nums text-label-2">
                {fmtPoint(item[e.key])}
              </span>
              <Stepper
                label={e.label}
                onDecrement={() => onNudge(item.id, e.key, -STEP)}
                onIncrement={() => onNudge(item.id, e.key, STEP)}
              />
            </span>
          </Row>
        ))}
      </Group>

      <Group header="Effort" footer={`About ${fmtSize(archiveMb(item))} in total.`}>
        <MenuRow<CadenceKey>
          label="How often"
          value={item.cadence}
          options={CADENCE_KEYS.map((k) => ({ value: k, label: CADENCE[k].label }))}
          onChange={(v) => mutate(item.id, (it) => ({ ...it, cadence: v }))}
        />
        <MenuRow<WeightKey>
          label="Size of one entry"
          value={item.weight}
          options={WEIGHT_KEYS.map((k) => ({ value: k, label: WEIGHTS[k].label }))}
          onChange={(v) => mutate(item.id, (it) => ({ ...it, weight: v }))}
        />
      </Group>

      <Group header="Rating" footer="Green is what you get. Red is what it costs.">
        {ASPECTS.map((a) => (
          <Row key={a.key} label={a.full}>
            <span className="ml-auto w-40 shrink-0">
              <SegmentedControl
                size="small"
                value={String(item.ratings[a.key])}
                options={[1, 2, 3, 4, 5].map((n) => ({ value: String(n), label: String(n) }))}
                onChange={(v) => mutate(item.id, (it) => ({
                  ...it, ratings: { ...it.ratings, [a.key]: Number(v) },
                }))}
              />
            </span>
          </Row>
        ))}
      </Group>

      <Group header="Needs">
        {NEED_KEYS.map((k) => (
          <CheckRow
            key={k}
            label={NEEDS[k]}
            selected={item.needs.includes(k)}
            onSelect={() => mutate(item.id, (it) => ({
              ...it,
              needs: it.needs.includes(k)
                ? it.needs.filter((n) => n !== k)
                : [...it.needs, k as NeedKey],
            }))}
          />
        ))}
      </Group>

      <Group header="Fields it writes">
        <FieldRows fields={item.fields}
          onChange={(fields) => mutate(item.id, (it) => ({ ...it, fields }))} />
      </Group>

      <Group header="Notes">
        <div className="pl-4">
          <div className="py-2 pr-4">
            <textarea
              value={item.note}
              placeholder="Open questions, decisions, things to check"
              onChange={(e) => mutate(item.id, (it) => ({ ...it, note: e.target.value }))}
              className="h-24 w-full resize-y bg-transparent text-body leading-relaxed text-label
                placeholder:text-label-4 focus:outline-none"
            />
          </div>
        </div>
      </Group>
    </Sheet>
  );
}

/* ============================================================
   What every feature depends on
   ============================================================ */

export function Dependencies({ items }: { items: Feature[] }) {
  const deps = useMemo(
    () => NEED_KEYS
      .map((k) => ({ key: k, users: items.filter((it) => it.needs.includes(k)) }))
      .filter((d) => d.users.length > 0)
      .sort((a, b) => b.users.length - a.users.length),
    [items],
  );

  return (
    <Group header="What has to exist">
      {deps.map((d) => (
        <Row key={d.key} label={NEEDS[d.key]}
          secondary={d.users.map((u) => u.name).join(", ")}
          trailing={<span className="text-subheadline tabular-nums">{d.users.length}</span>} />
      ))}
    </Group>
  );
}
